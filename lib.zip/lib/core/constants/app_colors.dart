import 'package:flutter/material.dart';

/// Design direction: a calm, clinical teal-blue (evoking Damascene ceramic
/// glaze) as the single brand color, driving every accent, gradient, and
/// highlight in the app - no secondary accent hue. Semantic colors
/// (success/warning/error) stay close to convention deliberately - clarity
/// matters more than novelty when someone is reading a lab result.
abstract final class AppColors {
  // Brand - light mode
  static const Color primary = Color(0xFF0B5566);

  // Soft tint of primary, used behind icon badges/avatars and as the middle
  // stop in splash/onboarding/role-selection gradients.
  static const Color primaryTint = Color(0xFFE6FFFA);

  // Brand - dark mode (brighter so it stays legible on dark surfaces; also
  // doubles as the app's only "accent" tone wherever a second shade is
  // needed alongside primary, e.g. two-stop gradients).
  static const Color primaryDark = Color(0xFF4FD8C4);

  // Dark-mode equivalent of primaryTint, used as the gradient middle stop
  // on dark backgrounds.
  static const Color primaryTintDark = Color(0xFF102A2E);

  // Neutrals - light mode
  static const Color background = Color(0xFFF6F8F9);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceAlt = Color(0xFFEFF3F4);
  static const Color textDark = Color(0xFF13232A);
  static const Color textGrey = Color(0xFF5B6B72);

  // Neutrals - dark mode
  static const Color backgroundDark = Color(0xFF0C1A1F);
  static const Color surfaceDarkTone = Color(0xFF162B31);
  static const Color surfaceAltDark = Color(0xFF1E363D);
  static const Color textLight = Color(0xFFEAF3F3);
  static const Color textGreyDark = Color(0xFFA7BCC1);

  static const Color white = Color(0xFFFFFFFF);

  // Semantic - kept close to convention on purpose
  static const Color success = Color(0xFF15954E);
  static const Color warning = Color(0xFFC5750A);
  static const Color error = Color(0xFFD8332B);
}
